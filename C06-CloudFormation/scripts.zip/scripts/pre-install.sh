#!/bin/bash

sudo yum update -y
sudo yum install -y python3-pip python3-dev build-essential
